// tab management
if(sessionStorage.getItem('tabName') == null) {
    sessionStorage.setItem('tabName', 'in-progress');
}
var currentTabName = document.getElementById(sessionStorage.getItem('tabName').concat('-link'));
currentTabName.click();
