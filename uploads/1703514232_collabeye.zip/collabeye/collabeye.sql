-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 16, 2023 at 07:14 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `collabeye`
--

-- --------------------------------------------------------

--
-- Table structure for table `artifact`
--

CREATE TABLE `artifact` (
  `artifact_id` mediumint(8) UNSIGNED NOT NULL,
  `type` enum('IMAGE','VIDEO','AUDIO','PDF') NOT NULL,
  `extension` enum('jpg','jpeg','png','gif','mp3','mp4','pdf') NOT NULL,
  `link` varchar(255) NOT NULL,
  `publication_id` mediumint(8) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `artist`
--

CREATE TABLE `artist` (
  `artist_id` mediumint(8) UNSIGNED NOT NULL,
  `first_name` varchar(35) NOT NULL,
  `last_name` varchar(35) NOT NULL,
  `dob` date NOT NULL,
  `city` varchar(35) NOT NULL,
  `country_id` mediumint(8) UNSIGNED NOT NULL,
  `bio` varchar(255) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `contact_email` varchar(50) DEFAULT `email`,
  `password` varchar(256) NOT NULL,
  `rating` decimal(2,1) DEFAULT 0.0,
  `likes` int(10) UNSIGNED DEFAULT 0,
  `profile_views` int(10) UNSIGNED DEFAULT 0,
  `profile_img` varchar(255) NOT NULL DEFAULT 'default image url here',
  `banner_img` varchar(255) NOT NULL DEFAULT '''Default banner link here''',
  `hireale` tinyint(1) DEFAULT 0,
  `contributable` tinyint(1) DEFAULT 0,
  `facebook_link` varchar(255) DEFAULT 'https://www.facebook.com/',
  `instagram_link` varchar(255) DEFAULT 'https://www.instagram.com/',
  `linkedin_link` varchar(255) DEFAULT 'https://www.linkedin.com/',
  `behance_link` varchar(255) DEFAULT 'https://www.behance.net/',
  `credits` double(10,2) DEFAULT 0.00,
  `credits_enabled` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `artist_specialization`
--

CREATE TABLE `artist_specialization` (
  `artist_id` mediumint(8) UNSIGNED NOT NULL,
  `specialization` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `collaborator`
--

CREATE TABLE `collaborator` (
  `collaborator_id` mediumint(8) UNSIGNED NOT NULL,
  `artist_id` mediumint(8) UNSIGNED NOT NULL,
  `project_id` mediumint(8) UNSIGNED NOT NULL,
  `no_of_tasks` mediumint(8) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `collab_request`
--

CREATE TABLE `collab_request` (
  `artist_id` mediumint(8) UNSIGNED NOT NULL,
  `pm_id` mediumint(8) UNSIGNED NOT NULL,
  `description` varchar(255) NOT NULL,
  `sent_date` date NOT NULL DEFAULT curdate(),
  `processed_date` date DEFAULT NULL,
  `expiration_days` tinyint(3) UNSIGNED NOT NULL DEFAULT 3,
  `request_status` enum('PENDING','ACCEPTED','REJECTED','EXPIRED','CANCELLED') NOT NULL DEFAULT 'PENDING',
  `payment_mode` enum('FREE','PAID') NOT NULL DEFAULT 'FREE',
  `payment` double(10,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

CREATE TABLE `country` (
  `country_id` mediumint(8) UNSIGNED NOT NULL,
  `country_name` varchar(50) NOT NULL,
  `country_code` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `country`
--

INSERT INTO `country` (`country_id`, `country_name`, `country_code`) VALUES
(1, 'Afghanistan', 'AF'),
(2, 'Albania', 'AL'),
(3, 'Algeria', 'DZ'),
(4, 'American Samoa', 'AS'),
(5, 'Andorra', 'AD'),
(6, 'Angola', 'AO'),
(7, 'Anguilla', 'AI'),
(8, 'Antarctica', 'AQ'),
(9, 'Antigua and Barbuda', 'AG'),
(10, 'Argentina', 'AR'),
(11, 'Armenia', 'AM'),
(12, 'Aruba', 'AW'),
(13, 'Australia', 'AU'),
(14, 'Austria', 'AT'),
(15, 'Azerbaijan', 'AZ'),
(16, 'Bahamas', 'BS'),
(17, 'Bahrain', 'BH'),
(18, 'Bangladesh', 'BD'),
(19, 'Barbados', 'BB'),
(20, 'Belarus', 'BY'),
(21, 'Belgium', 'BE'),
(22, 'Belize', 'BZ'),
(23, 'Benin', 'BJ'),
(24, 'Bermuda', 'BM'),
(25, 'Bhutan', 'BT'),
(26, 'Bosnia and Herzegovina', 'BA'),
(27, 'Botswana', 'BW'),
(28, 'Bouvet Island', 'BV'),
(29, 'Brazil', 'BR'),
(30, 'British Indian Ocean Territory', 'IO'),
(31, 'Brunei Darussalam', 'BN'),
(32, 'Bulgaria', 'BG'),
(33, 'Burkina Faso', 'BF'),
(34, 'Burundi', 'BI'),
(35, 'Cambodia', 'KH'),
(36, 'Cameroon', 'CM'),
(37, 'Canada', 'CA'),
(38, 'Cape Verde', 'CV'),
(39, 'Cayman Islands', 'KY'),
(40, 'Central African Republic', 'CF'),
(41, 'Chad', 'TD'),
(42, 'Chile', 'CL'),
(43, 'China', 'CN'),
(44, 'Christmas Island', 'CX'),
(45, 'Cocos (Keeling) Islands', 'CC'),
(46, 'Colombia', 'CO'),
(47, 'Comoros', 'KM'),
(48, 'Congo', 'CG'),
(49, 'Cook Islands', 'CK'),
(50, 'Costa Rica', 'CR'),
(51, 'Croatia', 'HR'),
(52, 'Cuba', 'CU'),
(53, 'Cyprus', 'CY'),
(54, 'Czech Republic', 'CZ'),
(55, 'Denmark', 'DK'),
(56, 'Djibouti', 'DJ'),
(57, 'Dominica', 'DM'),
(58, 'Dominican Republic', 'DO'),
(59, 'Ecuador', 'EC'),
(60, 'Egypt', 'EG'),
(61, 'El Salvador', 'SV'),
(62, 'Equatorial Guinea', 'GQ'),
(63, 'Eritrea', 'ER'),
(64, 'Estonia', 'EE'),
(65, 'Ethiopia', 'ET'),
(66, 'Falkland Islands (Malvinas)', 'FK'),
(67, 'Faroe Islands', 'FO'),
(68, 'Fiji', 'FJ'),
(69, 'Finland', 'FI'),
(70, 'France', 'FR'),
(71, 'French Guiana', 'GF'),
(72, 'French Polynesia', 'PF'),
(73, 'French Southern Territories', 'TF'),
(74, 'Gabon', 'GA'),
(75, 'Gambia', 'GM'),
(76, 'Georgia', 'GE'),
(77, 'Germany', 'DE'),
(78, 'Ghana', 'GH'),
(79, 'Gibraltar', 'GI'),
(80, 'Greece', 'GR'),
(81, 'Greenland', 'GL'),
(82, 'Grenada', 'GD'),
(83, 'Guadeloupe', 'GP'),
(84, 'Guam', 'GU'),
(85, 'Guatemala', 'GT'),
(86, 'Guernsey', 'GG'),
(87, 'Guinea', 'GN'),
(88, 'Guinea-Bissau', 'GW'),
(89, 'Guyana', 'GY'),
(90, 'Haiti', 'HT'),
(91, 'Heard Island and McDonald Islands', 'HM'),
(92, 'Holy See (Vatican City State)', 'VA'),
(93, 'Honduras', 'HN'),
(94, 'Hong Kong', 'HK'),
(95, 'Hungary', 'HU'),
(96, 'Iceland', 'IS'),
(97, 'India', 'IN'),
(98, 'Indonesia', 'ID'),
(99, 'Iran', 'IR'),
(100, 'Iraq', 'IQ'),
(101, 'Ireland', 'IE'),
(102, 'Isle of Man', 'IM'),
(103, 'Israel', 'IL'),
(104, 'Italy', 'IT'),
(105, 'Jamaica', 'JM'),
(106, 'Japan', 'JP'),
(107, 'Jersey', 'JE'),
(108, 'Jordan', 'JO'),
(109, 'Kazakhstan', 'KZ'),
(110, 'Kenya', 'KE'),
(111, 'Kiribati', 'KI'),
(112, 'Kuwait', 'KW'),
(113, 'Kyrgyzstan', 'KG'),
(114, 'Lao Peoples Democratic Republic', 'LA'),
(115, 'Latvia', 'LV'),
(116, 'Lebanon', 'LB'),
(117, 'Lesotho', 'LS'),
(118, 'Liberia', 'LR'),
(119, 'Libya', 'LY'),
(120, 'Liechtenstein', 'LI'),
(121, 'Lithuania', 'LT'),
(122, 'Luxembourg', 'LU'),
(123, 'Macao', 'MO'),
(124, 'Madagascar', 'MG'),
(125, 'Malawi', 'MW'),
(126, 'Malaysia', 'MY'),
(127, 'Maldives', 'MV'),
(128, 'Mali', 'ML'),
(129, 'Malta', 'MT'),
(130, 'Marshall Islands', 'MH'),
(131, 'Martinique', 'MQ'),
(132, 'Mauritania', 'MR'),
(133, 'Mauritius', 'MU'),
(134, 'Mayotte', 'YT'),
(135, 'Mexico', 'MX'),
(136, 'Monaco', 'MC'),
(137, 'Mongolia', 'MN'),
(138, 'Montenegro', 'ME'),
(139, 'Montserrat', 'MS'),
(140, 'Morocco', 'MA'),
(141, 'Mozambique', 'MZ'),
(142, 'Myanmar', 'MM'),
(143, 'Namibia', 'NA'),
(144, 'Nauru', 'NR'),
(145, 'Nepal', 'NP'),
(146, 'Netherlands', 'NL'),
(147, 'New Caledonia', 'NC'),
(148, 'New Zealand', 'NZ'),
(149, 'Nicaragua', 'NI'),
(150, 'Niger', 'NE'),
(151, 'Nigeria', 'NG'),
(152, 'Niue', 'NU'),
(153, 'Norfolk Island', 'NF'),
(154, 'Northern Mariana Islands', 'MP'),
(155, 'Norway', 'NO'),
(156, 'Oman', 'OM'),
(157, 'Pakistan', 'PK'),
(158, 'Palau', 'PW'),
(159, 'Panama', 'PA'),
(160, 'Papua New Guinea', 'PG'),
(161, 'Paraguay', 'PY'),
(162, 'Peru', 'PE'),
(163, 'Philippines', 'PH'),
(164, 'Pitcairn', 'PN'),
(165, 'Poland', 'PL'),
(166, 'Portugal', 'PT'),
(167, 'Puerto Rico', 'PR'),
(168, 'Qatar', 'QA'),
(169, 'Romania', 'RO'),
(170, 'Russian Federation', 'RU'),
(171, 'Rwanda', 'RW'),
(172, 'Saint Kitts and Nevis', 'KN'),
(173, 'Saint Lucia', 'LC'),
(174, 'Saint Martin (French part)', 'MF'),
(175, 'Saint Pierre and Miquelon', 'PM'),
(176, 'Saint Vincent and the Grenadines', 'VC'),
(177, 'Samoa', 'WS'),
(178, 'San Marino', 'SM'),
(179, 'Sao Tome and Principe', 'ST'),
(180, 'Saudi Arabia', 'SA'),
(181, 'Senegal', 'SN'),
(182, 'Serbia', 'RS'),
(183, 'Seychelles', 'SC'),
(184, 'Sierra Leone', 'SL'),
(185, 'Singapore', 'SG'),
(186, 'Sint Maarten (Dutch part)', 'SX'),
(187, 'Slovakia', 'SK'),
(188, 'Slovenia', 'SI'),
(189, 'Solomon Islands', 'SB'),
(190, 'Somalia', 'SO'),
(191, 'South Africa', 'ZA'),
(192, 'South Georgia and the South Sandwich Islands', 'GS'),
(193, 'South Sudan', 'SS'),
(194, 'Spain', 'ES'),
(195, 'Sri Lanka', 'LK'),
(196, 'State of Palestine', 'PS'),
(197, 'Sudan', 'SD'),
(198, 'Suriname', 'SR'),
(199, 'Svalbard and Jan Mayen', 'SJ'),
(200, 'Swaziland', 'SZ'),
(201, 'Sweden', 'SE'),
(202, 'Switzerland', 'CH'),
(203, 'Syrian Arab Republic', 'SY'),
(204, 'Tajikistan', 'TJ'),
(205, 'Thailand', 'TH'),
(206, 'Timor-Leste', 'TL'),
(207, 'Togo', 'TG'),
(208, 'Tokelau', 'TK'),
(209, 'Tonga', 'TO'),
(210, 'Trinidad and Tobago', 'TT'),
(211, 'Tunisia', 'TN'),
(212, 'Turkey', 'TR'),
(213, 'Turkmenistan', 'TM'),
(214, 'Turks and Caicos Islands', 'TC'),
(215, 'Tuvalu', 'TV'),
(216, 'Uganda', 'UG'),
(217, 'Ukraine', 'UA'),
(218, 'United Arab Emirates', 'AE'),
(219, 'United Kingdom', 'GB'),
(220, 'United States', 'US'),
(221, 'United States Minor Outlying Islands', 'UM'),
(222, 'Uruguay', 'UY'),
(223, 'Uzbekistan', 'UZ'),
(224, 'Vanuatu', 'VU'),
(225, 'Viet Nam', 'VN'),
(226, 'Wallis and Futuna', 'WF'),
(227, 'Western Sahara', 'EH'),
(228, 'Yemen', 'YE'),
(229, 'Zambia', 'ZM'),
(230, 'Zimbabwe', 'ZW');

-- --------------------------------------------------------

--
-- Table structure for table `dispute_report`
--

CREATE TABLE `dispute_report` (
  `report_id` mediumint(8) UNSIGNED NOT NULL,
  `reporter_id` mediumint(8) UNSIGNED NOT NULL,
  `reportee_id` mediumint(8) UNSIGNED NOT NULL,
  `description` varchar(255) NOT NULL,
  `moderator_id` mediumint(8) UNSIGNED DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `resolved_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `following_artist`
--

CREATE TABLE `following_artist` (
  `follower_id` mediumint(8) UNSIGNED NOT NULL,
  `following_id` mediumint(8) UNSIGNED NOT NULL,
  `followed_timestamp` date DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job`
--

CREATE TABLE `job` (
  `job_id` mediumint(8) UNSIGNED NOT NULL,
  `title` varchar(35) NOT NULL,
  `job_field` varchar(35) NOT NULL,
  `location` varchar(35) NOT NULL,
  `enrollment_type` varchar(35) NOT NULL,
  `short_description` varchar(100) DEFAULT NULL,
  `full_description` varchar(300) DEFAULT NULL,
  `artist_id` mediumint(8) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_application`
--

CREATE TABLE `job_application` (
  `application_id` mediumint(8) UNSIGNED NOT NULL,
  `artist_id` mediumint(8) UNSIGNED NOT NULL,
  `job_id` mediumint(8) UNSIGNED NOT NULL,
  `cv_link` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `like_artist`
--

CREATE TABLE `like_artist` (
  `likedby_id` mediumint(8) UNSIGNED NOT NULL,
  `liked_id` mediumint(8) UNSIGNED NOT NULL,
  `liked_timestamp` date DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `moderator`
--

CREATE TABLE `moderator` (
  `mod_id` mediumint(8) UNSIGNED NOT NULL,
  `first_name` varchar(35) NOT NULL,
  `last_name` varchar(35) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `profile_visit`
--

CREATE TABLE `profile_visit` (
  `visitor_id` mediumint(8) UNSIGNED NOT NULL,
  `visitee_id` mediumint(8) UNSIGNED NOT NULL,
  `visited_timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `project`
--

CREATE TABLE `project` (
  `project_id` mediumint(8) UNSIGNED NOT NULL,
  `name` varchar(35) NOT NULL,
  `description` varchar(255) NOT NULL,
  `project_status` varchar(20) NOT NULL DEFAULT 'IN-PROGRESS',
  `no_of_collaborators` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `last_edited_date` date NOT NULL DEFAULT curdate(),
  `completed_date` date DEFAULT NULL,
  `published_date` date DEFAULT NULL,
  `pm_id` mediumint(8) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `project_asset`
--

CREATE TABLE `project_asset` (
  `asset_id` mediumint(8) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `project_id` mediumint(8) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `project_chat`
--

CREATE TABLE `project_chat` (
  `chat_id` int(10) UNSIGNED NOT NULL,
  `project_id` mediumint(8) UNSIGNED NOT NULL,
  `artist_id` mediumint(8) UNSIGNED NOT NULL,
  `message_type` enum('TEXT','FILE') DEFAULT 'TEXT',
  `text_message` varchar(255) DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `sent_timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `project_manager`
--

CREATE TABLE `project_manager` (
  `pm_id` mediumint(8) UNSIGNED NOT NULL,
  `project_rating` decimal(2,1) DEFAULT 0.0,
  `artist_id` mediumint(8) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `publication`
--

CREATE TABLE `publication` (
  `publication_id` mediumint(8) UNSIGNED NOT NULL,
  `likes` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `view_count` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `thumbnail_link` varchar(255) NOT NULL DEFAULT 'Insert thumbnail url here',
  `no_of_files` tinyint(3) UNSIGNED NOT NULL DEFAULT 1,
  `for_sale` enum('YES','NO') NOT NULL DEFAULT 'NO',
  `price` double(10,2) DEFAULT NULL,
  `project_id` mediumint(8) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `publication_category`
--

CREATE TABLE `publication_category` (
  `publication_id` mediumint(8) UNSIGNED NOT NULL,
  `category` varchar(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `publication_comment`
--

CREATE TABLE `publication_comment` (
  `publication_id` mediumint(8) UNSIGNED NOT NULL,
  `artist_id` mediumint(8) UNSIGNED NOT NULL,
  `comment_content` varchar(255) NOT NULL,
  `posted_date` date NOT NULL DEFAULT curdate()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `purchase`
--

CREATE TABLE `purchase` (
  `artist_id` mediumint(8) UNSIGNED NOT NULL,
  `publication_id` mediumint(8) UNSIGNED NOT NULL,
  `purchase_date` date NOT NULL DEFAULT curdate()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `report_publication`
--

CREATE TABLE `report_publication` (
  `report_id` mediumint(8) UNSIGNED NOT NULL,
  `artist_id` mediumint(8) UNSIGNED NOT NULL,
  `publication_id` mediumint(8) UNSIGNED NOT NULL,
  `moderator_id` mediumint(8) UNSIGNED DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `reported_timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `handled_timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `report_user`
--

CREATE TABLE `report_user` (
  `report_id` mediumint(8) UNSIGNED NOT NULL,
  `reporter_id` mediumint(8) UNSIGNED NOT NULL,
  `reportee_id` mediumint(8) UNSIGNED NOT NULL,
  `description` varchar(255) NOT NULL,
  `created_date` date NOT NULL DEFAULT curdate(),
  `handled_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `report_status` enum('PENDING','HANDLED') NOT NULL DEFAULT 'PENDING',
  `sysmanager_id` tinyint(3) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `source_file_request`
--

CREATE TABLE `source_file_request` (
  `request_id` int(10) UNSIGNED NOT NULL,
  `artist_id` mediumint(8) UNSIGNED NOT NULL,
  `publication_id` mediumint(8) UNSIGNED NOT NULL,
  `req_status` enum('PENDING','ACCEPTED','REJECTED') DEFAULT 'PENDING',
  `sent_timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `processed_timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `system_detail_report`
--

CREATE TABLE `system_detail_report` (
  `report_id` mediumint(8) UNSIGNED NOT NULL,
  `report_link` varchar(255) NOT NULL,
  `generated_timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `generated_by` tinyint(3) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `system_manager`
--

CREATE TABLE `system_manager` (
  `sysmanager_id` tinyint(3) UNSIGNED NOT NULL,
  `first_name` varchar(35) NOT NULL,
  `last_name` varchar(35) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `task`
--

CREATE TABLE `task` (
  `task_id` mediumint(8) UNSIGNED NOT NULL,
  `name` varchar(35) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `start_date` date NOT NULL DEFAULT curdate(),
  `end_date` date NOT NULL,
  `payment` double(10,2) NOT NULL,
  `task_status` varchar(35) NOT NULL DEFAULT 'TO-DO',
  `collaborator_id` mediumint(8) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `task_feedback`
--

CREATE TABLE `task_feedback` (
  `task_feedback_id` mediumint(8) UNSIGNED NOT NULL,
  `task_id` mediumint(8) UNSIGNED NOT NULL,
  `feedback` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_chat`
--

CREATE TABLE `user_chat` (
  `chat_id` int(10) UNSIGNED NOT NULL,
  `first_user` mediumint(8) UNSIGNED NOT NULL,
  `second_user` mediumint(8) UNSIGNED NOT NULL,
  `text_message` varchar(255) NOT NULL,
  `sent_timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `artifact`
--
ALTER TABLE `artifact`
  ADD PRIMARY KEY (`artifact_id`),
  ADD KEY `publication_id` (`publication_id`);

--
-- Indexes for table `artist`
--
ALTER TABLE `artist`
  ADD PRIMARY KEY (`artist_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `country_id` (`country_id`);

--
-- Indexes for table `artist_specialization`
--
ALTER TABLE `artist_specialization`
  ADD PRIMARY KEY (`artist_id`,`specialization`),
  ADD UNIQUE KEY `specialization` (`specialization`);

--
-- Indexes for table `collaborator`
--
ALTER TABLE `collaborator`
  ADD PRIMARY KEY (`collaborator_id`),
  ADD KEY `artist_id` (`artist_id`),
  ADD KEY `project_id` (`project_id`);

--
-- Indexes for table `collab_request`
--
ALTER TABLE `collab_request`
  ADD PRIMARY KEY (`artist_id`,`pm_id`),
  ADD KEY `pm_id` (`pm_id`);

--
-- Indexes for table `country`
--
ALTER TABLE `country`
  ADD PRIMARY KEY (`country_id`);

--
-- Indexes for table `dispute_report`
--
ALTER TABLE `dispute_report`
  ADD PRIMARY KEY (`report_id`),
  ADD KEY `reporter_id` (`reporter_id`),
  ADD KEY `reportee_id` (`reportee_id`),
  ADD KEY `moderator_id` (`moderator_id`);

--
-- Indexes for table `following_artist`
--
ALTER TABLE `following_artist`
  ADD PRIMARY KEY (`follower_id`,`following_id`),
  ADD KEY `following_id` (`following_id`);

--
-- Indexes for table `job`
--
ALTER TABLE `job`
  ADD PRIMARY KEY (`job_id`),
  ADD KEY `artist_id` (`artist_id`);

--
-- Indexes for table `job_application`
--
ALTER TABLE `job_application`
  ADD PRIMARY KEY (`application_id`),
  ADD KEY `artist_id` (`artist_id`),
  ADD KEY `job_id` (`job_id`);

--
-- Indexes for table `like_artist`
--
ALTER TABLE `like_artist`
  ADD PRIMARY KEY (`likedby_id`,`liked_id`),
  ADD KEY `liked_id` (`liked_id`);

--
-- Indexes for table `moderator`
--
ALTER TABLE `moderator`
  ADD PRIMARY KEY (`mod_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `profile_visit`
--
ALTER TABLE `profile_visit`
  ADD PRIMARY KEY (`visitor_id`,`visitee_id`,`visited_timestamp`),
  ADD KEY `visitee_id` (`visitee_id`);

--
-- Indexes for table `project`
--
ALTER TABLE `project`
  ADD PRIMARY KEY (`project_id`),
  ADD KEY `pm_id` (`pm_id`);

--
-- Indexes for table `project_asset`
--
ALTER TABLE `project_asset`
  ADD PRIMARY KEY (`asset_id`),
  ADD KEY `project_id` (`project_id`);

--
-- Indexes for table `project_chat`
--
ALTER TABLE `project_chat`
  ADD PRIMARY KEY (`chat_id`),
  ADD KEY `project_id` (`project_id`),
  ADD KEY `artist_id` (`artist_id`);

--
-- Indexes for table `project_manager`
--
ALTER TABLE `project_manager`
  ADD PRIMARY KEY (`pm_id`),
  ADD KEY `artist_id` (`artist_id`);

--
-- Indexes for table `publication`
--
ALTER TABLE `publication`
  ADD PRIMARY KEY (`publication_id`),
  ADD KEY `project_id` (`project_id`);

--
-- Indexes for table `publication_category`
--
ALTER TABLE `publication_category`
  ADD PRIMARY KEY (`publication_id`,`category`);

--
-- Indexes for table `publication_comment`
--
ALTER TABLE `publication_comment`
  ADD PRIMARY KEY (`publication_id`,`artist_id`),
  ADD KEY `artist_id` (`artist_id`);

--
-- Indexes for table `purchase`
--
ALTER TABLE `purchase`
  ADD PRIMARY KEY (`artist_id`,`publication_id`),
  ADD KEY `publication_id` (`publication_id`);

--
-- Indexes for table `report_publication`
--
ALTER TABLE `report_publication`
  ADD PRIMARY KEY (`report_id`),
  ADD KEY `artist_id` (`artist_id`),
  ADD KEY `publication_id` (`publication_id`),
  ADD KEY `moderator_id` (`moderator_id`);

--
-- Indexes for table `report_user`
--
ALTER TABLE `report_user`
  ADD PRIMARY KEY (`report_id`),
  ADD KEY `reporter_id` (`reporter_id`),
  ADD KEY `reportee_id` (`reportee_id`),
  ADD KEY `sysmanager_id` (`sysmanager_id`);

--
-- Indexes for table `source_file_request`
--
ALTER TABLE `source_file_request`
  ADD PRIMARY KEY (`request_id`),
  ADD KEY `artist_id` (`artist_id`),
  ADD KEY `publication_id` (`publication_id`);

--
-- Indexes for table `system_detail_report`
--
ALTER TABLE `system_detail_report`
  ADD PRIMARY KEY (`report_id`),
  ADD KEY `generated_by` (`generated_by`);

--
-- Indexes for table `system_manager`
--
ALTER TABLE `system_manager`
  ADD PRIMARY KEY (`sysmanager_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `task`
--
ALTER TABLE `task`
  ADD PRIMARY KEY (`task_id`),
  ADD KEY `collaborator_id` (`collaborator_id`);

--
-- Indexes for table `task_feedback`
--
ALTER TABLE `task_feedback`
  ADD PRIMARY KEY (`task_feedback_id`),
  ADD KEY `task_id` (`task_id`);

--
-- Indexes for table `user_chat`
--
ALTER TABLE `user_chat`
  ADD PRIMARY KEY (`chat_id`),
  ADD KEY `first_user` (`first_user`),
  ADD KEY `second_user` (`second_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `artifact`
--
ALTER TABLE `artifact`
  MODIFY `artifact_id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `artist`
--
ALTER TABLE `artist`
  MODIFY `artist_id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `collaborator`
--
ALTER TABLE `collaborator`
  MODIFY `collaborator_id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `country`
--
ALTER TABLE `country`
  MODIFY `country_id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=231;

--
-- AUTO_INCREMENT for table `dispute_report`
--
ALTER TABLE `dispute_report`
  MODIFY `report_id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `job`
--
ALTER TABLE `job`
  MODIFY `job_id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `job_application`
--
ALTER TABLE `job_application`
  MODIFY `application_id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `moderator`
--
ALTER TABLE `moderator`
  MODIFY `mod_id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `project`
--
ALTER TABLE `project`
  MODIFY `project_id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `project_asset`
--
ALTER TABLE `project_asset`
  MODIFY `asset_id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `project_chat`
--
ALTER TABLE `project_chat`
  MODIFY `chat_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `project_manager`
--
ALTER TABLE `project_manager`
  MODIFY `pm_id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `publication`
--
ALTER TABLE `publication`
  MODIFY `publication_id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `report_publication`
--
ALTER TABLE `report_publication`
  MODIFY `report_id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `report_user`
--
ALTER TABLE `report_user`
  MODIFY `report_id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `source_file_request`
--
ALTER TABLE `source_file_request`
  MODIFY `request_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `system_detail_report`
--
ALTER TABLE `system_detail_report`
  MODIFY `report_id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `system_manager`
--
ALTER TABLE `system_manager`
  MODIFY `sysmanager_id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `task`
--
ALTER TABLE `task`
  MODIFY `task_id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `task_feedback`
--
ALTER TABLE `task_feedback`
  MODIFY `task_feedback_id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_chat`
--
ALTER TABLE `user_chat`
  MODIFY `chat_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `artifact`
--
ALTER TABLE `artifact`
  ADD CONSTRAINT `artifact_ibfk_1` FOREIGN KEY (`publication_id`) REFERENCES `publication` (`publication_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `artist`
--
ALTER TABLE `artist`
  ADD CONSTRAINT `artist_ibfk_1` FOREIGN KEY (`country_id`) REFERENCES `country` (`country_id`);

--
-- Constraints for table `artist_specialization`
--
ALTER TABLE `artist_specialization`
  ADD CONSTRAINT `artist_specialization_ibfk_1` FOREIGN KEY (`artist_id`) REFERENCES `artist` (`artist_id`) ON UPDATE CASCADE;

--
-- Constraints for table `collaborator`
--
ALTER TABLE `collaborator`
  ADD CONSTRAINT `collaborator_ibfk_1` FOREIGN KEY (`artist_id`) REFERENCES `artist` (`artist_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `collaborator_ibfk_2` FOREIGN KEY (`project_id`) REFERENCES `project` (`project_id`) ON UPDATE CASCADE;

--
-- Constraints for table `collab_request`
--
ALTER TABLE `collab_request`
  ADD CONSTRAINT `collab_request_ibfk_1` FOREIGN KEY (`artist_id`) REFERENCES `artist` (`artist_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `collab_request_ibfk_2` FOREIGN KEY (`pm_id`) REFERENCES `project_manager` (`pm_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `dispute_report`
--
ALTER TABLE `dispute_report`
  ADD CONSTRAINT `dispute_report_ibfk_1` FOREIGN KEY (`reporter_id`) REFERENCES `artist` (`artist_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `dispute_report_ibfk_2` FOREIGN KEY (`reportee_id`) REFERENCES `artist` (`artist_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `dispute_report_ibfk_3` FOREIGN KEY (`moderator_id`) REFERENCES `moderator` (`mod_id`) ON UPDATE CASCADE;

--
-- Constraints for table `following_artist`
--
ALTER TABLE `following_artist`
  ADD CONSTRAINT `following_artist_ibfk_1` FOREIGN KEY (`follower_id`) REFERENCES `artist` (`artist_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `following_artist_ibfk_2` FOREIGN KEY (`following_id`) REFERENCES `artist` (`artist_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `job`
--
ALTER TABLE `job`
  ADD CONSTRAINT `job_ibfk_1` FOREIGN KEY (`artist_id`) REFERENCES `artist` (`artist_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `job_application`
--
ALTER TABLE `job_application`
  ADD CONSTRAINT `job_application_ibfk_1` FOREIGN KEY (`artist_id`) REFERENCES `artist` (`artist_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `job_application_ibfk_2` FOREIGN KEY (`job_id`) REFERENCES `job` (`job_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `like_artist`
--
ALTER TABLE `like_artist`
  ADD CONSTRAINT `like_artist_ibfk_1` FOREIGN KEY (`likedby_id`) REFERENCES `artist` (`artist_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `like_artist_ibfk_2` FOREIGN KEY (`liked_id`) REFERENCES `artist` (`artist_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `profile_visit`
--
ALTER TABLE `profile_visit`
  ADD CONSTRAINT `profile_visit_ibfk_1` FOREIGN KEY (`visitor_id`) REFERENCES `artist` (`artist_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `profile_visit_ibfk_2` FOREIGN KEY (`visitee_id`) REFERENCES `artist` (`artist_id`) ON UPDATE CASCADE;

--
-- Constraints for table `project`
--
ALTER TABLE `project`
  ADD CONSTRAINT `project_ibfk_1` FOREIGN KEY (`pm_id`) REFERENCES `project_manager` (`pm_id`) ON UPDATE CASCADE;

--
-- Constraints for table `project_asset`
--
ALTER TABLE `project_asset`
  ADD CONSTRAINT `project_asset_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `project` (`project_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `project_chat`
--
ALTER TABLE `project_chat`
  ADD CONSTRAINT `project_chat_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `project` (`project_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `project_chat_ibfk_2` FOREIGN KEY (`artist_id`) REFERENCES `artist` (`artist_id`) ON UPDATE CASCADE;

--
-- Constraints for table `project_manager`
--
ALTER TABLE `project_manager`
  ADD CONSTRAINT `project_manager_ibfk_1` FOREIGN KEY (`artist_id`) REFERENCES `artist` (`artist_id`);

--
-- Constraints for table `publication`
--
ALTER TABLE `publication`
  ADD CONSTRAINT `publication_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `project` (`project_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `publication_category`
--
ALTER TABLE `publication_category`
  ADD CONSTRAINT `publication_category_ibfk_1` FOREIGN KEY (`publication_id`) REFERENCES `publication` (`publication_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `publication_comment`
--
ALTER TABLE `publication_comment`
  ADD CONSTRAINT `publication_comment_ibfk_1` FOREIGN KEY (`publication_id`) REFERENCES `publication` (`publication_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `publication_comment_ibfk_2` FOREIGN KEY (`artist_id`) REFERENCES `artist` (`artist_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `purchase`
--
ALTER TABLE `purchase`
  ADD CONSTRAINT `purchase_ibfk_1` FOREIGN KEY (`artist_id`) REFERENCES `artist` (`artist_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `purchase_ibfk_2` FOREIGN KEY (`publication_id`) REFERENCES `publication` (`publication_id`) ON UPDATE CASCADE;

--
-- Constraints for table `report_publication`
--
ALTER TABLE `report_publication`
  ADD CONSTRAINT `report_publication_ibfk_1` FOREIGN KEY (`artist_id`) REFERENCES `artist` (`artist_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `report_publication_ibfk_2` FOREIGN KEY (`publication_id`) REFERENCES `publication` (`publication_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `report_publication_ibfk_3` FOREIGN KEY (`moderator_id`) REFERENCES `moderator` (`mod_id`) ON UPDATE CASCADE;

--
-- Constraints for table `report_user`
--
ALTER TABLE `report_user`
  ADD CONSTRAINT `report_user_ibfk_1` FOREIGN KEY (`reporter_id`) REFERENCES `artist` (`artist_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `report_user_ibfk_2` FOREIGN KEY (`reportee_id`) REFERENCES `artist` (`artist_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `report_user_ibfk_3` FOREIGN KEY (`sysmanager_id`) REFERENCES `system_manager` (`sysmanager_id`) ON UPDATE CASCADE;

--
-- Constraints for table `source_file_request`
--
ALTER TABLE `source_file_request`
  ADD CONSTRAINT `source_file_request_ibfk_1` FOREIGN KEY (`artist_id`) REFERENCES `artist` (`artist_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `source_file_request_ibfk_2` FOREIGN KEY (`publication_id`) REFERENCES `publication` (`publication_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `system_detail_report`
--
ALTER TABLE `system_detail_report`
  ADD CONSTRAINT `system_detail_report_ibfk_1` FOREIGN KEY (`generated_by`) REFERENCES `system_manager` (`sysmanager_id`) ON UPDATE CASCADE;

--
-- Constraints for table `task`
--
ALTER TABLE `task`
  ADD CONSTRAINT `task_ibfk_1` FOREIGN KEY (`collaborator_id`) REFERENCES `collaborator` (`collaborator_id`) ON UPDATE CASCADE;

--
-- Constraints for table `task_feedback`
--
ALTER TABLE `task_feedback`
  ADD CONSTRAINT `task_feedback_ibfk_1` FOREIGN KEY (`task_id`) REFERENCES `task` (`task_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_chat`
--
ALTER TABLE `user_chat`
  ADD CONSTRAINT `user_chat_ibfk_1` FOREIGN KEY (`first_user`) REFERENCES `artist` (`artist_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `user_chat_ibfk_2` FOREIGN KEY (`second_user`) REFERENCES `artist` (`artist_id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
