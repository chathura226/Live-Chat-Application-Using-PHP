<?php

// database class for database configurations
class Database {

    // database conection
    private function connect() {
        $str = DBDRIVER.":hostname=".DBHOST.";dbname=".DBNAME;
        return new PDO($str, DBUSER, DBPASS);
    }

    // query the database
    public function query($query, $data = [], $type = 'object') {
        $conn = $this->connect();

        $stm = $conn->prepare($query);
        if($stm) {
            $check = $stm->execute($data);
            if($check) {
                if($type == 'object') {
                    $type = PDO::FETCH_OBJ;
                } else {
                    $type = PDO::FETCH_ASSOC;
                }

                $result = $stm->fetchAll($type);

                if(is_array($result) && count($result) > 0) {
                    return $result;
                }
            }
        }

        return false;
    }

    // create tables in the database
    public function create_tables() {
        $query = 
            "   
            CREATE TABLE `artist` (
                `artist_id` mediumint(8) UNSIGNED NOT NULL,
                `first_name` varchar(35) NOT NULL,
                `last_name` varchar(35) NOT NULL,
                `dob` date NOT NULL,
                `city` varchar(35) NOT NULL,
                `country_id` mediumint(8) UNSIGNED NOT NULL,
                `bio` varchar(255) DEFAULT NULL,
                `email` varchar(50) NOT NULL,
                `contact_email` varchar(50) DEFAULT `email`,
                `password` varchar(256) NOT NULL,
                `rating` decimal(2,1) DEFAULT 0.0,
                `likes` int(10) UNSIGNED DEFAULT 0,
                `profile_views` int(10) UNSIGNED DEFAULT 0,
                `profile_img` varchar(255) NOT NULL DEFAULT 'default image url here',
                `banner_img` varchar(255) NOT NULL DEFAULT '''Default banner link here''',
                `hireale` tinyint(1) DEFAULT 0,
                `contributable` tinyint(1) DEFAULT 0,
                `facebook_link` varchar(255) DEFAULT 'https://www.facebook.com/',
                `instagram_link` varchar(255) DEFAULT 'https://www.instagram.com/',
                `linkedin_link` varchar(255) DEFAULT 'https://www.linkedin.com/',
                `behance_link` varchar(255) DEFAULT 'https://www.behance.net/',
                `credits` double(10,2) DEFAULT 0.00,
                `credits_enabled` tinyint(1) DEFAULT 0
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

            ";

        $this->query($query);
    }
}