<?php

class Model extends Database{
    protected $table = "" ;
    public function insert($data){
        //remove unwanted columns
        if(!empty($this->allowedColumns)){
            foreach($data as $key => $value){
                if(!in_array($key, $this->allowedColumns)){
                    unset($data[$key]);
                }   
            }
        }
    
        $keys = array_keys($data);
        $values = array_values($data);
    
        $query = "INSERT INTO " . $this->table . " (" . implode(",", $keys) . ") VALUES (:" . implode(", :", $keys) . ")";
    
        $this->query($query,$data);
    
    }

    
    public function where($data){
        $keys = array_keys($data);

        $query = "select * from ".$this->table. " where ";
        
        foreach($keys as $key){
            $query .=  $key . "=:" . $key . " && ";
        }

        $query = trim($query,"&& ");
        $res = $this->query($query,$data);

        if(is_array($res)){
            return $res;
        }
        return false;
    
    }

    public function first($data) {

        $keys = array_keys($data);

        $query = "SELECT * FROM " . $this->table . " WHERE ";
        
        foreach($keys as $key) {
            $query .= "$key = :$key" . " && ";
        }

        //* Trim removes characters from the end and the beginning of a string
        $query = trim($query, "&& ");

        $query .= " ORDER BY artist_id DESC LIMIT 1";
        $result = $this->query($query, $data);

        if(is_array($result)) return $result[0];
        else return false;
    }


}
