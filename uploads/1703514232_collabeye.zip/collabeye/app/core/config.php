<?php

// application configurations
define('APP_NAME', 'CollabEye');
define('APP_DESC', 'Artist Collaboration Platform');

// server configurations
if($_SERVER['SERVER_NAME'] == 'localhost') {
    // development
    define('DBHOST', 'localhost');
    define('DBNAME', 'collabeye');
    define('DBUSER', 'root');
    define('DBPASS', '');
    define('DBDRIVER', 'mysql');

    // development root
    define('ROOT', 'http://localhost/collabeye/public');
} else {
    // production
    define('DBHOST', 'localhost');
    define('DBNAME', 'collabeye');
    define('DBUSER', 'root');
    define('DBPASS', '');
    define('DBDRIVER', 'mysql');
}