<?php

namespace Model;

class User extends Model {
    public $errors = [];
    protected $table = 'users';

    protected $allowed_columns = [
        'email',
        'first_name',
        'last_name',
        'password',
        'role',
        'date'
    ];

    public function validate($data) {
        $this->errors = [];

        if(empty($data['first_name'])) {
            $this->errors['first_name'] = "First name is required";
        }

        if(empty($data['last_name'])) {
            $this->errors['last_name'] = "Last name is required";
        }

        if(filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            $this->errors['email'] = "Email is invalid";
        }
        if($this->where(['email' => $data['email']])) {
            $this->errors['email'] = "Email already exists";
        }

        if(empty($data['password'])) {
            $this->errors['password'] = "Password is required";
        }

        if(empty($data['retype_password'])) {
            $this->errors['retype_password'] = "Confirm Password is required";
        }

        if(!empty($data['password']) && !empty($data['retype_password'])) {
            if($data['password'] != $data['retype_password']) {
                $this->errors['password'] = "Passwords do not match";
            }
        }

        if(empty($data['terms'])) {
            $this->errors['terms'] = "Please accept terms and conditions";
        }

        if(empty($this->errors)) {
            return true;
        }

        return false;
    }
}