<?php

namespace Model;

if(!defined("ROOT")) die ("direct script access denied");

// authentication class
class Auth {

    // authenticate a user
    public static function authenticate($row){
        if(is_object($row)) {
            $_SESSION['artist_DATA'] = $row;
        }
    }

    // logout a user
    public static function logout() {
        if(!empty($_SESSION['artist_DATA'])) {
            unset($_SESSION['artist_DATA']);
        }
    }

    // check whether a user is logged in or not
    public static function logged_in() {
        if(!empty($_SESSION['artist_DATA'])) {
            return true;
        }
        return false;
    }

    // get user attributes from USER_DATA
    public static function __callStatic($func_name, $args) {
        $key = str_replace("get", "", strtolower($func_name));
        if(!empty($_SESSION['USER_DATA']->$key)) {
            return $_SESSION['USER_DATA']->$key;
        }
        return '';
    } 
}