<?php

namespace Model;
 
if(!defined("ROOT")) die ("direct script access denied");

// model class for a project
class Project extends Model {
    public $errors = [];
    protected $table = 'project';

    protected $allowed_columns = [
        'name',
        'description',
        'project_status',
        'no_of_collaborators',
        'last_edited_date',
        'completed_date',
        'published_date',
        'pm_id'
    ];
}