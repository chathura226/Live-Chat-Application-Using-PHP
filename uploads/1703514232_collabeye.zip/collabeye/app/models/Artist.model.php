<?php

class Artist extends Model{
    public $errors = [];
    protected $table = "artist";

    protected $allowedColumns = [
        'artist_id',
        'first_name',
        'last_name',
        'dob',	
        'city',	
        'country_id',		
        'email',		
        'password'
    ];

    public function validate($data) {
        $this->errors = [];
    
        if(empty($data['first_name'])){
            $this->errors['first_name'] = "First name is required" ; 
        }
        if(empty($data['last_name'])){
            $this->errors['last_name'] = "Last name is required" ; 
        }
        if(empty($data['dob'])){
            $this->errors['dob'] = "Date of Birth is required" ; 
        }
        if(empty($data['city'])){
            $this->errors['city'] = "City is required" ; 
        }
        if(empty($data['country_id'])){
            $this->errors['country_id'] = "Country is required" ; 
        }

        //check email
        if(!filter_var($data['email'], FILTER_VALIDATE_EMAIL)){
            $this->errors['email'] = "Email is not valid" ; 
        }
        else if($this->query("SELECT * FROM artist WHERE email = :email", ['email' => $data['email']])){
            $this->errors['email'] = "That email already exists" ; 
        }


        if(empty($data['password'])){
            $this->errors['password'] = "Password is required" ; 
        }
        if(!preg_match_all('$\S*(?=\S{8,})(?=\S*[a-z])(?=\S*[A-Z])(?=\S*[\d])(?=\S*[\W])\S*$', $data['password'])) {
            $this->errors['password'] = "Password is not Strong enough";
        }
        if($data['password'] !== $data['confirm_password']){
             $this->errors['confirm_password'] = "Passwords do not match";
        }

        //if(empty($data['terms'])){
            //$this->errors['terms'] = "Please accept Terms and Conditions";
        //}

        if(empty($this->errors)){
            return true;
        }

        return false;
       
    }


    
}