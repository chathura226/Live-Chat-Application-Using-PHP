<h2>404 Not Found</h2>
<h5><?= $var?></h5>