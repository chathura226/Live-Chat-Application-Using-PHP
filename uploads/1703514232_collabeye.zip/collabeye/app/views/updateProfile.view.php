<?php
$artist_id = $_SESSION['artist_id'];
if (!isset($artist_id)) {
    header('location:login');
};
?>

<?php $this->view("includes/header") ?>

<!-- TOP NAVIGATION -->
<?php $this->view("includes/components/topnavbar") ?>

<img class="artist-profile" src="../img/components/artist-profile.png">

<div class="artist-form-container">
    <form action="" method="POST" enctype="multipart/form-data">
        <!-- Personal Information -->
        <div class="frame">
            <div class="header">
                <left>
                    <h4><b>Personal Information</b></h4>
                </left>
            </div>

            <div class="form-row">
                <div>
                    <span>First Name</span>
                    <input type="text" name="first_name" value="<?=$data['first_name']?>">
                </div>
                <div>
                    <span>Last Name</span>
                    <input type="text" name="last_name" value="<?=$data['last_name']?>">
                </div>
            </div>

            <div class="form-drag-area">
                <div class="icon">
                    <img src="<?php echo ROOT; ?>/img/imageUpload/avatar-placeholder.png" alt="placeholder" width="90px" height="90px" class="profile-image-placeholder">
                </div>
                <div class="right-content">
                    <div class="description">Drag & Drop to upload file</div>
                    <div class="form-upload">
                        <input type="file" name="profile_image" class="profile_image" style="display: none;">
                        Browse File
                    </div>
                </div>
            </div>
            <div class="form-validation">
                <div class="profile-image-validation">
                    <img src="<?php echo ROOT; ?>/img/imageUpload/tick.png" width="15px" height="15px">
                    Select a profile picture
                </div>
            </div>

            <div class="form-row">
                <div>
                    <span>Date of Birth</span>
                    <input type="text" name="dob" value="<?= $data['dob']?>">
                </div>

            </div>

            <div class="form-row">
                <div>
                    <span>City</span>
                    <input type="text" name="city" value="<?=$data['city']?>">
                </div>
                <div>
                    <span>Country</span>
                    <input type="text" name="country_id" value="<?=$data['country_id']?>">
                </div>
            </div>

        </div>

        <!-- Account Information -->
        <div class="frame">
            <div class="header">
                <left>
                    <h4><b>Account Information</b></h4>
                </left>
            </div>

            <div class="form-row">
                <div>
                    <span>Email</span>
                    <input type="text" name="email" value="<?=$data['email']?>">
                </div>
                <div>
                    <span>Old Password</span>
                    <input type="password" name="old_password" class="box">
                </div>
            </div>

            <div class="form-row">
                <div>
                    <span>New Password</span>
                    <input type="password" name="new_password" class="box">
                </div>
                <div>
                    <span>Confirm Password</span>
                    <input type="password" name="confirm_password" class="box">
                </div>
            </div>

        </div>

        <!-- Profile Details -->
        <div class="frame">
            <div class="header">
                <left>
                    <h4><b>Profile Details</b></h4>
                </left>
            </div>

            <div class="form-row">
                <div>
                    <span>Specification</span>
                    <input type="text" name="specification" value="<?=$data['specification']?>">
                </div>
                <div>
                    <span>Contact Email Address</span>
                    <input type="text" name="contact_email" value="<?=$data['contact_email']?>">
                </div>
            </div>

            <div class="form-row">
                <div>
                    <span>Bio</span>
                    <div class="bio">
                        <textarea type="text" name="bio" class="styled-input"><?=$data['bio']?></textarea>
                    </div>
                </div>
            </div>


            <!-- Profile Links -->
            <div class="header">
                <left>
                    <h4><b>Profile Links</b></h4>
                </left>
            </div>

            <div class="form-row">
                <div>
                    <span>Facebook &nbsp;<img src="../img/components/facebook.png"></span>
                    <input type="text" name="facebook" value="<?=$data['facebook']?>">
                </div>
                <div>
                    <span>Instagram &nbsp;<img src="../img/components/insta.png"></span>
                    <input type="text" name="instagram" value="<?=$data['instagram']?>">
                </div>
            </div>

            <div class="form-row">
                <div>
                    <span>Behance &nbsp;<img src="../img/components/behance.png"></span>
                    <input type="text" name="behance" value="<?=$data['behance']?>">
                </div>
                <div>
                    <span>LinkedIn &nbsp;<img src="../img/components/linkedin.png"></span>
                    <input type="text" name="linkedIn" value="<?=$data['linkedIn']?>">
                </div>
            </div>

        </div>

        <!-- Profile Settings -->
        <div class="frame">
            <div class="header">
                <left>
                    <h4><b>Profile Settings</b></h4>
                </left>
            </div>

            <div class="form-row">
                <div>
                    <span>Hire</span>
                    <label class="switch">
                        <input type="checkbox">
                        <span class="slider round"></span>
                    </label>
                </div>
                <div>
                    <span>Contribution</span>
                    <label class="switch">
                        <input type="checkbox">
                        <span class="slider round"></span>
                    </label>
                </div>
            </div>

        </div>
        <div class="form-row-button">
        <input type="submit" value="Cancel" class="btnCancel">
        <input type="submit" value="Save Changes" class="btnSave">
        </div>

    </div>
</div>

<!--Javascript for profile image -->
<script type="text/javascript" src="<?php echo ROOT; ?>/js/components/imageUpload.js"></script>

<?php $this->view("includes/footer") ?>