<?php

require('includes/header.view.php');
require('includes/nav.view.php');

?>

<div class="banner">
    <img src="<?=ROOT?>/assets/images/banner-projects.png" style="width: 100%;"/>
</div>

<div class="search-bar">
    <div class="search-bar-content">
        <!-- <img class="search-icon" src="<?=ROOT?>/assets/images/search-icon.png" /> -->
        <i class="fa-solid fa-magnifying-glass search-icon"></i>
        <form class="search-input-wrapper" method="POST">
            <input class="search-input" type="text" name="search-input" placeholder="Search Your Projects">
            <button class="button button-light bold search-bar-button" type="submit" name="submit" value="submit">Search</button>
        </form>
        <!-- <img class="verticle-line" src="<?=ROOT?>/assets/images/verticle-line.png" /> -->

        <div class="vl-wrapper">
            <div class="vl"></div>
            <div class="button-container">
                <button class="button button-light bold search-bar-button" onclick="openTab(event, 'in-progress')" id="in-progress-link">In-Progress</button>
                <button class="button button-light bold search-bar-button" onclick="openTab(event, 'completed')" id="completed-link">Completed</button>
                <button class="button button-light bold search-bar-button" onclick="openTab(event, 'published')" id="published-link">Published</button>
            </div>
        </div>
    </div>
    <img class="rectangle" src="<?=ROOT?>/assets/images/search-outline.png" />
</div>

<div id="in-progress" class="tabcontent">
    <button class="button-new-project" data-modal-target="#modal">
        <span>
            <svg width="80" height="80" viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                <circle cx="35" cy="35" r="35" fill="#BAA378"/>
                <rect x="15" y="15" width="40" height="40" fill="url(#pattern0)"/>
                <defs>
                <pattern id="pattern0" patternContentUnits="objectBoundingBox" width="1" height="1">
                <use xlink:href="#image0_0_1" transform="scale(0.0208333)"/>
                </pattern>
                <image id="image0_0_1" width="48" height="48" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAAAXNSR0IArs4c6QAAATRJREFUaAXtmM0OwjAMgznx6oz35OcxjCrmi4WZpkzMQHqJkqXt12Q9uIdDj65AXgUAHAGcAdwAXAFMI5ZHaohmYMiYTHpeeK688OOeR2qIlJy+Sc8LE1htHqkhUnD6Jj0vTGC1eaSGSMHpm/S8MIHV5pEaIgWnb9LzwgRWm0dqiBScvknPCxNYbR6pIVJw+iY9L0xgtXmkhkjB6Zv0vDCB1eaRGiIFp2/StwuLkuK+KXZZ2RkllXIAcnhlZ5QUJ6ZYr+xmAZ4C6jgu9tJ8yS90eneA8RwynkDGhUkby5fYnmzlB3fylcvsl94H2K/2z527A92BYgX6FyoWsDy9O1AuYXGB7kCxgOXp3YFyCYsL/EIHXukJr6SKBdt8ulF2XkltTlBccH6eobL7nJIqcvf0v6zAAyqTOEgZ3ccLAAAAAElFTkSuQmCC"/>
                </defs>
            </svg>
        </span><br />
        <span class="gold-text">Add New Project</span>
    </button>
    <div class="modal" id="modal">
    <div class="modal-header">
        <button data-close-button class="close-button">&times;</button>
    </div>
    <div class="modal-body">
        <form method="POST">
            <label class="bold">Project Name</label><br />
            <input class="input-box input-text-popup" type="text" name="project-name" /><br />
            <label class="bold">Project Description</label><br />
            <!-- <input class="input-box input-textarea-popup" type="textarea" name="project-desc" rows="7" cols="50" /><br /> -->
            <textarea class="input-box input-textarea-popup" name="project-desc" rows="7" cols="50"></textarea><br />
            <button class="button button-dark bold" type="submit" name="submit" value="submit">Continue</button>
        </form>
    </div>
    </div>
    <div id="overlay"></div>
</div>

<div id="completed" class="tabcontent">

</div>

<div id="published" class="tabcontent">

</div>

<?php

require('includes/footer.view.php');