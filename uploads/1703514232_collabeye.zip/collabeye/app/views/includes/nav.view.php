<?php

use \Model\Auth;

?>

<nav id="navbar" class="navbar">
    <a href = "<?=ROOT?>"><img class="img" src="<?=ROOT?>/assets/images/logo.png" /></a>
    <ul>
       <li><a class="bold" href="<?=ROOT?>/home">Home</a></li> 
       <li><a class="bold" href="<?=ROOT?>/artists">Artists</a></li> 
       <li><a class="bold" href="<?=ROOT?>/projects">Projects</a></li> 
       <li><a class="bold" href="<?=ROOT?>/shop">Shop</a></li> 
       <li><a class="bold" href="<?=ROOT?>/jobs">Jobs</a></li> 
    </ul>
    <div class="wrapper">
        <?php if(Auth::logged_in()):?>
            <img class="img" src="img/image-5.png" />
            <img class="img" src="img/image-6.png" />
            <div class="frame">
                <img class="ellipse" src="img/ellipse-1.png" />
                <div class="text-wrapper">Gerald Nelson</div>
            </div>
        <?php else: ?>
            <button class="button button-light bold" id="login">Log In</button>
            <button class="button button-dark bold" id="signup">Sign Up</button>
        <?php endif ?>
    </div>
</nav>

<hr />

<main id="main">