<script src="<?=ROOT?>/assets/js/globals.js"></script>
<script src="<?=ROOT?>/assets/js/<?=strtolower($data['title'])?>.js"></script>
</main>
</body>
</html>