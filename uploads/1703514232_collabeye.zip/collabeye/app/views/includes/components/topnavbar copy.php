<img class="logo-image" src="../images/components/logo.png">

<div class="topnav"> 
    <a class="active" href="#home">Home</a>
    <a href="#artists">Artists</a>
    <a href="#projects">Projects</a>
    <a href="#hire">Hire</a>
    <a href="#shop">Shop</a>
    <a href="#jobs">Jobs</a>
    <a href="<?php echo ROOT?>/auth/login">Login</a>
    <a href="<?php echo ROOT?>/auth/signup">Register</a>
</div>