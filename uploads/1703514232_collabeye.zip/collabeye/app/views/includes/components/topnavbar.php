<?php
$artist_id = $_SESSION['artist_id'];
if (!isset($artist_id)) {
    header('location:login.php');
};
?>

<div class="topnav">
    <img class="logo-image" src="../img/components/logo.png">
    <div style="flex:1">
        <a class="active" href="#home">Home</a>
        <a href="#artists">Artists</a>
        <a href="#projects">Projects</a>
        <a href="#shop">Shop</a>
        <a href="#jobs">Jobs</a>
    </div>
    <a href="#notification"><img class="icon-img" src="../img/components/notification.png"></a>
    <a href="#message"><img class="icon-img" src="../img/components/message.png"></a>

    <a href="<?php echo ROOT ?>/Pages/updateProfile">
        <img class="profile" src="../img/imageUpload/<?= !empty($fetch_profile['image']) ? $fetch_profile['image'] : '../img/components/profile.png'; ?>">
    </a>

    <div class="profile-name">
        <a href="#update-profile"><span><?php echo ($_SESSION['Artist_first_name']); echo ('&nbsp;'); echo ($_SESSION['Artist_last_name']); ?></span></a>
    </div>

</div>