<?php $this->view("includes/header") ?>

<!--IMPORTANT BUG-->
<style>
    body {
        overflow-x: hidden;
    }
</style>

<body style="background-image: url('./assets/images/components/login.jpg');" class="login-body">

    <!--<img class="login-image" src="../img/components/login.jpg">-->

    <div class="title">
        <h1><b>CollabEye</b></h1>
    </div>

    <div class="form-container">
        <div class="form-header">
            <left>
                <h1><b>Login</b></h1>
            </left>
            <p>Don't have an Account? Sign Up <a href="<?= ROOT ?>/signup">here</a></p> <br>
        </div>

        <?php if (message()) : ?>
            <div class="alert-msg cols-12"><?= message('', true); ?></div>
        <?php else : ?>
            <div></div>
        <?php endif; ?>

        <form action="" method="POST">
            <!-- EMAIL -->
            <div class="form-input-title"><img class="icon-image" src="./assets/images/components/email.png">&nbsp;&nbsp;Email Address</div>
            <input type="text" name="email" id="email" class="email">
            <span class="form-invalid"></span> <br><br>

            <!-- PASSWORD -->
            <div styleclass="form-input-title"><img class="icon-image" src="./assets/images/components/password.png">&nbsp;&nbsp;Password</div>
            <input type="password" name="password" id="password" class="password">
            <span class="form-invalid"></span>

            <br>
            <input type="submit" value="Login" class="form-btn">

        </form>

    </div>
</body>

<?php $this->view("includes/footer") ?>