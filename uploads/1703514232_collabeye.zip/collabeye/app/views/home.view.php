<?php
$artist_id = $_SESSION['artist_id'];
if (!isset($artist_id)) {
    header('location:login');
};
?>

<?php $this->view("includes/header") ?>

<!-- TOP NAVIGATION -->
<?php $this->view("includes/components/topnavbar") ?>

<br><br>
<div class="home-discover-tab">

    <div class="top-icons">

        <div class="search-bar">
            <img class="icon-image" src="../img/components/search.png">
            <input type="text" placeholder="What are you looking for...">
            <button type="submit">Search</button>
            <div class="tabs">
            <a href="#">Discover</a>
            <a href="#">Following</a>
            <a href="#">For You</a>
            </div>
        </div>
        <br><br>
        <div class="sort-selection-bar">
            <p class="sort-selection"><img class="icon-image" src="../img/components/sort-selection.png">&nbsp;&nbsp;Sort Selection</p>
            <!--<select name="sort">
                <option value="default">Default</option>
                <option value="popularity">Popularity</option>
                <option value="newest">Newest</oldest>
            </select>-->
        </div>
    </div>

    <hr>

</div>

<?php $this->view("includes/footer") ?>