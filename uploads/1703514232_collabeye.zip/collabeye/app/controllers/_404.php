<?php

namespace Controller;
class _404 extends Controller{
    public function index() {
        $data['var'] = "Check the URL";
        $this->view('404', $data);
    }
} 