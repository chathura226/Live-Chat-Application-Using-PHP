<?php

namespace Controller;

class Home extends Controller {
    public function index() {
        $data['title'] = "Home";
        $this->view('home', $data);
    }

    public function edit($id) {
        echo "editing user ".$id;
    }

    public function delete($id) {
        echo "delete user ".$id;
    }
} 