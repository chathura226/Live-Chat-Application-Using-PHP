<?php

class Signup extends Controller{
    public function index(): void
    {
        $data['errors'] = [];

        $artist = new Artist();

        if($_SERVER['REQUEST_METHOD'] == "POST") {
            if($artist->validate($_POST)) {

                $_POST['password'] = password_hash($_POST['password'], PASSWORD_DEFAULT);

                $_POST['artist_id'] = "artist_".rand(1000, 100000) . "_" . time();

                $artist->insert($_POST);

                message("Your profile was created successfully. Please Login");
                redirect('login');
            } else {
                $data['errors'] = $artist->errors;
            }
        }

        
        $data['title'] = "CollabEye | Signup";
        $this->view('auth/signup', $data);
    }
}