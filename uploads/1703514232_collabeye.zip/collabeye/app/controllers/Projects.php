<?php

namespace Controller;

class Projects extends Controller {
    public function index() {
        $data['title'] = "Projects";
        $this->view('projects', $data);
    }
}